echo java -agentpath:$(dirname $0)/../amd64/libswing-inspector-agent.so -classpath $(dirname $0)/Java2D.jar java2d.Java2Demo
java -agentpath:$(dirname $0)/../amd64/libswing-inspector-agent.so -classpath $(dirname $0)/Java2D.jar java2d.Java2Demo

JAVA_CMD=java

if [ -x "/usr/lib/jvm/java-7-openjdk-i386/bin/java" ]; then
	JAVA_CMD=/usr/lib/jvm/java-7-openjdk-i386/bin/java
elif [ -x "/usr/lib/jvm/java-6-openjdk-i386/bin/java" ]; then
	JAVA_CMD=/usr/lib/jvm/java-6-openjdk-i386/bin/java
fi

echo $JAVA_CMD -agentpath:$(dirname $0)/../i386/libswing-inspector-agent.so -classpath $(dirname $0)/Java2D.jar java2d.Java2Demo
$JAVA_CMD -agentpath:$(dirname $0)/../i386/libswing-inspector-agent.so -classpath $(dirname $0)/Java2D.jar java2d.Java2Demo
